# Initialize scanner module
