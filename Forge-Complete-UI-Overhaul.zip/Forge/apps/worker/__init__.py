# Worker entrypoint
