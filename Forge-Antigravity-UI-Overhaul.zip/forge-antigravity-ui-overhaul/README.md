# Forge Antigravity UI Overhaul Bundle

Start with:

`FORGE_ANTIGRAVITY_COMPLETE_UI_OVERHAUL.md`

Give that file and the entire `reference-ui/` directory to Antigravity inside
the existing Forge repository.

The reference directory contains the exact approved implementation of:

- the interactive blue WebGL blob;
- the transparent overscan that prevents clipping;
- the off-white and rich-blue design system;
- the typography and layout foundation;
- the current responsive website;
- the product and design constraints.

Antigravity should copy and adapt the reference implementation into the real
Forge application while preserving backend behavior and following the master
prompt.

